<div class="copyright">
	<?php echo wp_kses_post( html_entity_decode( multiple_business_get_option( 'footer_text' ) ) ); ?> <?php esc_html_e( 'Multiple Business Theme by', 'multiple-business' ); ?> <a href="<?php echo esc_url( '//keonthemes.com' ); ?>" target="_blank"> <?php esc_html_e( 'Keon Themes', 'multiple-business' ); ?> </a>
</div><!-- .site-info -->