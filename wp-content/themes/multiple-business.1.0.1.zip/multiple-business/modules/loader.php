<?php
/**
* Load all the modules
* @since Multiple Business 1.0.0
*/
require get_parent_theme_file_path( '/modules/helpers/loader.php' );
require get_parent_theme_file_path( '/modules/breadcrumbs/loader.php' );
require get_parent_theme_file_path( '/modules/excerpt/class-excerpt.php' );
require get_parent_theme_file_path( '/modules/customizer/loader.php' );
